@extends('layouts.app')

@section('content')
<login-admin-component></login-admin-component
@endsection