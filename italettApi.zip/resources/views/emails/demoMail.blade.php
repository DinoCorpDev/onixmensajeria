<!DOCTYPE html>
<html>
<head>
    <title>Cambio de Contraseña Solicitado</title>
</head>
<body>
    <h1>Tu Correo es: {{ $data[0] }}</h1>
    <p>Tu Nueva Contraseña es: {{ $data[1] }}</p>
    
    <p>Ingresa de nuevo a la plataforma y podras cambiar la clave nuevamente para mayor seguridad</p>
</body>
</html>